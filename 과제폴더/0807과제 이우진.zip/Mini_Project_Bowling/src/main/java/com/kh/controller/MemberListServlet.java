package com.kh.controller;

import java.io.IOException;
import java.util.List;

import com.kh.mvc.model.MemberDTO;
import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// 현재 이용중(STATUS='Y')인 볼러 목록 조회 후 list.jsp로 이동
@WebServlet("/member/list")
public class MemberListServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final MemberService service = MemberService.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        List<MemberDTO> list = service.getActiveList();
        req.setAttribute("list", list);
        req.getRequestDispatcher("/WEB-INF/views/member/list.jsp").forward(req, resp);
    }
}
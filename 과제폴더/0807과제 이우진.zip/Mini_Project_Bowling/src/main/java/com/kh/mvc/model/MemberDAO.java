package com.kh.mvc.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.kh.mvc.util.DBUtil;

// BOWLER / BILLING 테이블에 대한 SQL 처리 + Connection 관리까지 모두 담당 (싱글톤)
public class MemberDAO {

    private static final MemberDAO INSTANCE = new MemberDAO();

    private MemberDAO() {
    }

    public static MemberDAO getInstance() {
        return INSTANCE;
    }

    // 신규 볼러 등록
    public boolean insertBowler(MemberDTO dto) {
        String sql = "INSERT INTO BOWLER (BOWLER_ID, NAME, LANE_NUMBER, GAME_COUNT, GRADE, STATUS) "
                   + "VALUES (SEQ_BOWLER_ID.NEXTVAL, ?, ?, ?, ?, 'Y')";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, dto.getName());
            pstmt.setInt(2, dto.getLaneNumber());
            pstmt.setInt(3, dto.getGameCount());
            pstmt.setString(4, dto.getGrade());
            int result = pstmt.executeUpdate();
            conn.commit();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 현재 이용중(STATUS='Y')인 볼러 목록 조회
    public List<MemberDTO> selectActiveList() {
        String sql = "SELECT BOWLER_ID, NAME, LANE_NUMBER, GAME_COUNT, GRADE, STATUS "
                   + "FROM BOWLER WHERE STATUS = 'Y' ORDER BY BOWLER_ID DESC";
        List<MemberDTO> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                MemberDTO dto = new MemberDTO();
                dto.setBowlerId(rs.getInt("BOWLER_ID"));
                dto.setName(rs.getString("NAME"));
                dto.setLaneNumber(rs.getInt("LANE_NUMBER"));
                dto.setGameCount(rs.getInt("GAME_COUNT"));
                dto.setGrade(rs.getString("GRADE"));
                dto.setStatus(rs.getString("STATUS"));
                list.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // 정산 시 요금 계산에 필요한 GAME_COUNT, GRADE 조회
    public MemberDTO selectOne(int bowlerId) {
        String sql = "SELECT BOWLER_ID, GAME_COUNT, GRADE FROM BOWLER WHERE BOWLER_ID = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, bowlerId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                MemberDTO dto = new MemberDTO();
                dto.setBowlerId(rs.getInt("BOWLER_ID"));
                dto.setGameCount(rs.getInt("GAME_COUNT"));
                dto.setGrade(rs.getString("GRADE"));
                return dto;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 정산 처리: BILLING insert + BOWLER.STATUS -> 'N' 을 한 트랜잭션으로 묶어서 처리
    public boolean pay(int bowlerId, int totalFee) {
        String insertSql = "INSERT INTO BILLING (BILLING_ID, BOWLER_ID, TOTAL_FEE) "
                         + "VALUES (SEQ_BILLING_ID.NEXTVAL, ?, ?)";
        String updateSql = "UPDATE BOWLER SET STATUS = 'N' WHERE BOWLER_ID = ?";

        try (Connection conn = DBUtil.getConnection()) {
            try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                pstmt.setInt(1, bowlerId);
                pstmt.setInt(2, totalFee);
                pstmt.executeUpdate();
            }
            try (PreparedStatement pstmt = conn.prepareStatement(updateSql)) {
                pstmt.setInt(1, bowlerId);
                pstmt.executeUpdate();
            }
            conn.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 회원 물리 삭제 (FK의 ON DELETE CASCADE로 BILLING 이력도 같이 삭제됨)
    public boolean deleteBowler(int bowlerId) {
        String sql = "DELETE FROM BOWLER WHERE BOWLER_ID = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, bowlerId);
            int result = pstmt.executeUpdate();
            conn.commit();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 전체 리셋: BOWLER 전부 삭제(CASCADE로 BILLING도 같이 삭제) + 시퀀스 초기화
    public boolean resetAll() {
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("DELETE FROM BOWLER");
            stmt.executeUpdate("ALTER SEQUENCE SEQ_BOWLER_ID RESTART START WITH 1");
            stmt.executeUpdate("ALTER SEQUENCE SEQ_BILLING_ID RESTART START WITH 1");
            conn.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 정산 건별 전체 조회 (BOWLER와 조인해서 회원명도 같이, 최신순)
    public List<BillingDTO> selectAllBilling() {
        String sql = "SELECT B.BILLING_ID, B.BOWLER_ID, B.TOTAL_FEE, B.PAYMENT_DATE, W.NAME "
                   + "FROM BILLING B JOIN BOWLER W ON B.BOWLER_ID = W.BOWLER_ID "
                   + "ORDER BY B.PAYMENT_DATE DESC";
        List<BillingDTO> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                BillingDTO dto = new BillingDTO();
                dto.setBillingId(rs.getInt("BILLING_ID"));
                dto.setBowlerId(rs.getInt("BOWLER_ID"));
                dto.setTotalFee(rs.getInt("TOTAL_FEE"));
                dto.setPaymentDate(rs.getTimestamp("PAYMENT_DATE"));
                dto.setBowlerName(rs.getString("NAME"));
                list.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
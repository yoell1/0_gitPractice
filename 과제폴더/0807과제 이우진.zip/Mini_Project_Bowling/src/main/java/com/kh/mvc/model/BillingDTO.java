package com.kh.mvc.model;

import java.sql.Timestamp;

// BILLING 테이블 한 행(row)을 담는 DTO
public class BillingDTO {

    private int billingId;
    private int bowlerId;
    private int totalFee;
    private Timestamp paymentDate;  // 결산 목록 조회용
    private String bowlerName;      // 결산 목록 조회용 (BOWLER와 조인해서 채움)

    public BillingDTO() {
    }

    // 정산 insert 시 사용: billingId는 시퀀스 채번, 결제일자는 DB가 SYSDATE로 자동 입력
    public BillingDTO(int bowlerId, int totalFee) {
        this.bowlerId = bowlerId;
        this.totalFee = totalFee;
    }

    public int getBillingId() { return billingId; }
    public void setBillingId(int billingId) { this.billingId = billingId; }

    public int getBowlerId() { return bowlerId; }
    public void setBowlerId(int bowlerId) { this.bowlerId = bowlerId; }

    public int getTotalFee() { return totalFee; }
    public void setTotalFee(int totalFee) { this.totalFee = totalFee; }

    public Timestamp getPaymentDate() { return paymentDate; }
    public void setPaymentDate(Timestamp paymentDate) { this.paymentDate = paymentDate; }

    public String getBowlerName() { return bowlerName; }
    public void setBowlerName(String bowlerName) { this.bowlerName = bowlerName; }
}
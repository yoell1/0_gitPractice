package com.kh.mvc.service;

import java.util.List;

import com.kh.mvc.model.MemberDAO;
import com.kh.mvc.model.MemberDTO;
import com.kh.mvc.model.BillingDTO;

// 업무 흐름 + 요금 계산만 담당. Connection은 이제 DAO가 다 처리함
public class MemberService {

    private static final MemberService INSTANCE = new MemberService();

    private static final int NORMAL_PRICE = 6000;
    private static final int VIP_PRICE = 4000;

    private final MemberDAO dao = MemberDAO.getInstance();

    private MemberService() {
    }

    public static MemberService getInstance() {
        return INSTANCE;
    }

    public boolean insertMember(MemberDTO dto) {
        return dao.insertBowler(dto);
    }

    public List<MemberDTO> getActiveList() {
        return dao.selectActiveList();
    }

    public boolean payMember(int bowlerId) {
        MemberDTO member = dao.selectOne(bowlerId);
        if (member == null) {
            return false;
        }
        int unitPrice = "VIP".equals(member.getGrade()) ? VIP_PRICE : NORMAL_PRICE;
        int totalFee = member.getGameCount() * unitPrice;
        return dao.pay(bowlerId, totalFee);
    }

    public boolean deleteMember(int bowlerId) {
        return dao.deleteBowler(bowlerId);
    }

    public boolean resetAll() {
        return dao.resetAll();
    }

    public List<BillingDTO> getSalesReport() {
        return dao.selectAllBilling();
    }
}
package com.kh.mvc.model;

// BOWLER 테이블 한 행(row)을 담는 DTO
public class MemberDTO {

    private int bowlerId;     // PK, 시퀀스로 자동 채번
    private String name;      // 이름
    private int laneNumber;   // 레인 번호 (1~20)
    private int gameCount;    // 게임 수 (요금 계산에 쓰임)
    private String grade;     // '일반' | 'VIP'
    private String status;    // 'Y'(이용중) | 'N'(퇴장/정산완료)

    public MemberDTO() {
    }

    // 신규 등록 시 사용: bowlerId는 시퀀스가 채번, status는 무조건 'Y'로 시작
    public MemberDTO(String name, int laneNumber, int gameCount, String grade) {
        this.name = name;
        this.laneNumber = laneNumber;
        this.gameCount = gameCount;
        this.grade = grade;
        this.status = "Y";
    }

    public int getBowlerId() { return bowlerId; }
    public void setBowlerId(int bowlerId) { this.bowlerId = bowlerId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getLaneNumber() { return laneNumber; }
    public void setLaneNumber(int laneNumber) { this.laneNumber = laneNumber; }

    public int getGameCount() { return gameCount; }
    public void setGameCount(int gameCount) { this.gameCount = gameCount; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
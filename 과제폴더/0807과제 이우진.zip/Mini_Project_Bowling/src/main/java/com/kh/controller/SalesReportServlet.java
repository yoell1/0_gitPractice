package com.kh.controller;

import java.io.IOException;
import java.util.List;

import com.kh.mvc.model.BillingDTO;
import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// 날짜별 매출 결산 조회
@WebServlet("/member/sales")
public class SalesReportServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final MemberService service = MemberService.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        List<BillingDTO> salesList = service.getSalesReport();
        req.setAttribute("salesList", salesList);
        req.getRequestDispatcher("/WEB-INF/views/member/sales.jsp").forward(req, resp);
    }
}
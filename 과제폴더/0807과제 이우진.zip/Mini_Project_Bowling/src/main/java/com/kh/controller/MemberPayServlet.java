package com.kh.controller;

import java.io.IOException;

import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// 정산 처리: BILLING insert + BOWLER.STATUS -> 'N' (파라미터: bowlerId)
@WebServlet("/member/pay")
public class MemberPayServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final MemberService service = MemberService.getInstance();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int bowlerId = Integer.parseInt(req.getParameter("bowlerId"));

        service.payMember(bowlerId);

        resp.sendRedirect(req.getContextPath() + "/member/list");
    }
}
package com.kh.controller;

import java.io.IOException;

import com.kh.mvc.model.MemberDTO;
import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// 신규 볼러 등록 처리 (파라미터: name, laneNumber, gameCount, grade)
@WebServlet("/member/insert")
public class MemberInsertServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final MemberService service = MemberService.getInstance();

    // 등록 폼 화면 보여주기
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/member/insert.jsp").forward(req, resp);
    }
    // 폼에서 입력받은 값으로 등록 처리 후 목록으로 이동
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        String name = req.getParameter("name");
        int laneNumber = Integer.parseInt(req.getParameter("laneNumber"));
        int gameCount = Integer.parseInt(req.getParameter("gameCount"));
        String grade = req.getParameter("grade");

        service.insertMember(new MemberDTO(name, laneNumber, gameCount, grade));

        resp.sendRedirect(req.getContextPath() + "/member/list");
    }
}
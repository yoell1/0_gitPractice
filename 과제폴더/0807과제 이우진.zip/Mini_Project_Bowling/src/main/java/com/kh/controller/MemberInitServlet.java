package com.kh.controller;

import java.io.IOException;

import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// 전체 데이터 리셋 (BOWLER 삭제 -> CASCADE로 BILLING도 삭제, 시퀀스 초기화)
@WebServlet("/member/init")
public class MemberInitServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private final MemberService service = MemberService.getInstance();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        service.resetAll();

        resp.sendRedirect(req.getContextPath() + "/member/list");
    }
}
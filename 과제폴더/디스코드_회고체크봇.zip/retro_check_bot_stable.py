"""
회고 체크 봇 (안정화 버전)
==========================
개선점
 1. 슬래시 명령 sync 를 setup_hook 에서 프로세스당 1회만 (on_ready 반복 sync 제거)
 2. 상태를 SQLite 에 저장 → 재시작해도 마지막 집계 유지
 3. 모든 명령에 전역 에러 핸들러 + 즉시 defer (3초 타임아웃 방지)
 4. 반응 조회량이 많으면 진행상황을 갱신해 15분 토큰 만료 방지
 5. 파일 로깅 + 연결/재연결 로그 → 언제 왜 죽었는지 추적 가능

환경변수
  DISCORD_TOKEN  (필수)
  GUILD_ID       (권장) 서버 ID. 넣으면 명령이 즉시 반영되고 레이트리밋 위험이 거의 없음
  DB_PATH        (선택) 기본 botdata.sqlite3

실행:  pip install -U discord.py  &&  python retro_check_bot_stable.py
"""

import asyncio
import json
import logging
import os
import sqlite3
from logging.handlers import RotatingFileHandler

import discord
from discord import app_commands
from discord.ext import commands, tasks

TOKEN = os.getenv("DISCORD_TOKEN", "")
GUILD_ID = int(os.getenv("GUILD_ID", "0")) or None
DB_PATH = os.getenv("DB_PATH", "botdata.sqlite3")

# ── 로깅 ─────────────────────────────────────────────────────
log = logging.getLogger("retrobot")
log.setLevel(logging.INFO)
_fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
_fh = RotatingFileHandler("bot.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
_fh.setFormatter(_fmt)
_sh = logging.StreamHandler()
_sh.setFormatter(_fmt)
log.addHandler(_fh)
log.addHandler(_sh)


# ── 영속 저장 (SQLite) ───────────────────────────────────────
def _conn():
    c = sqlite3.connect(DB_PATH, timeout=10)
    c.execute("CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL)")
    return c


def kv_set(key: str, value) -> None:
    with _conn() as c:
        c.execute(
            "INSERT INTO kv(k, v) VALUES(?, ?) "
            "ON CONFLICT(k) DO UPDATE SET v = excluded.v",
            (key, json.dumps(value, ensure_ascii=False)),
        )


def kv_get(key: str, default=None):
    with _conn() as c:
        row = c.execute("SELECT v FROM kv WHERE k = ?", (key,)).fetchone()
    return json.loads(row[0]) if row else default


# ── 봇 정의 ──────────────────────────────────────────────────
intents = discord.Intents.default()
intents.members = True
intents.voice_states = True
intents.reactions = True


class RetroBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        # ★ 핵심: 여기는 프로세스 시작 시 딱 한 번만 실행된다.
        #   on_ready 는 재접속마다 불리므로 절대 여기에 sync 를 두면 안 된다.
        _conn().close()
        try:
            if GUILD_ID:
                g = discord.Object(id=GUILD_ID)
                self.tree.copy_global_to(guild=g)
                synced = await self.tree.sync(guild=g)
                log.info("길드 %s 명령 동기화 완료 (%d개)", GUILD_ID, len(synced))
            else:
                synced = await self.tree.sync()
                log.warning(
                    "전역 동기화 (%d개). 반영에 최대 1시간, 레이트리밋 위험. "
                    "GUILD_ID 환경변수 설정을 권장합니다.",
                    len(synced),
                )
        except discord.HTTPException as e:
            log.exception("명령 동기화 실패 (봇은 계속 동작): %s", e)
        health_ping.start()


bot = RetroBot()


@tasks.loop(minutes=30)
async def health_ping():
    """살아있음을 로그에 남긴다. 로그가 끊긴 시점 = 죽은 시점."""
    log.info("정상 동작 중 | 지연 %.0fms | 서버 %d개", bot.latency * 1000, len(bot.guilds))


@bot.event
async def on_ready():
    log.info("접속 완료: %s (%s)", bot.user, bot.user.id)


@bot.event
async def on_disconnect():
    log.warning("게이트웨이 연결 끊김 — 자동 재연결 시도")


@bot.event
async def on_resumed():
    log.info("게이트웨이 재연결 성공")


@bot.tree.error
async def on_app_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    """예외를 삼키지 않고 사용자에게 알린다. 이게 없으면 '앱이 응답하지 않았습니다'만 뜬다."""
    log.exception("명령 오류: %s", error)
    msg = f"⚠️ 오류가 발생했습니다.\n```{type(error).__name__}: {error}```"
    try:
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    except discord.HTTPException:
        pass


# ── 유틸 ─────────────────────────────────────────────────────
def chunk_names(guild: discord.Guild, ids: set[int], limit: int = 900) -> list[str]:
    if not ids:
        return ["없음"]
    names = sorted(
        (guild.get_member(u).display_name if guild.get_member(u) else f"(퇴장:{u})")
        for u in ids
    )
    chunks, buf = [], ""
    for n in names:
        piece = (", " if buf else "") + n
        if len(buf) + len(piece) > limit:
            chunks.append(buf)
            buf = n
        else:
            buf += piece
    if buf:
        chunks.append(buf)
    return chunks


def add_list_field(embed: discord.Embed, title: str, guild, ids: set[int]):
    for i, ch in enumerate(chunk_names(guild, ids)):
        embed.add_field(name=title if i == 0 else f"{title} (계속)", value=ch, inline=False)


def resolve_targets(interaction, voice_channel, role):
    if role:
        return {m.id for m in role.members if not m.bot}, f"역할 @{role.name}"
    vc = voice_channel or (interaction.user.voice.channel if interaction.user.voice else None)
    if vc is None:
        return None
    return {m.id for m in vc.members if not m.bot}, f"음성채널 #{vc.name}"


# ── 반응 체크 ────────────────────────────────────────────────
@bot.tree.command(name="반응체크", description="최근 글들에 이모지를 누른 사람 / 안 누른 사람을 집계합니다.")
@app_commands.describe(
    개수="훑어볼 최근 메시지 수 (기본 30, 최대 100)",
    음성채널="대상 음성 채널 (비우면 내가 있는 채널)",
    역할="음성채널 대신 이 역할 전체를 대상으로",
    이모지="특정 이모지만 인정 (비우면 아무 이모지나)",
    전체반응="모든 글에 반응해야 완료로 인정",
)
async def reaction_check(
    interaction: discord.Interaction,
    개수: app_commands.Range[int, 1, 100] = 30,
    음성채널: discord.VoiceChannel | None = None,
    역할: discord.Role | None = None,
    이모지: str | None = None,
    전체반응: bool = False,
):
    await interaction.response.defer()  # ★ 무조건 먼저. 3초 넘으면 인터랙션이 죽는다.

    resolved = resolve_targets(interaction, 음성채널, 역할)
    if resolved is None:
        await interaction.followup.send("음성 채널에 들어가거나 `음성채널`/`역할` 옵션을 지정해주세요.")
        return
    targets, target_desc = resolved

    posts = [m async for m in interaction.channel.history(limit=개수) if not m.author.bot]
    posts.reverse()
    if not posts:
        await interaction.followup.send("집계할 메시지가 없습니다.")
        return

    total_calls = sum(len(m.reactions) for m in posts)
    progress = None
    if total_calls > 40:  # 오래 걸릴 땐 진행 메시지를 띄워 토큰 만료를 피한다
        progress = await interaction.followup.send(
            f"집계 중... 0/{len(posts)}", wait=True
        )

    reacted_per_post: dict[int, set[int]] = {}
    for i, msg in enumerate(posts, 1):
        users: set[int] = set()
        for r in msg.reactions:
            if 이모지 and str(r.emoji) != 이모지:
                continue
            try:
                async for u in r.users():
                    if not u.bot:
                        users.add(u.id)
            except discord.HTTPException as e:
                log.warning("반응 조회 실패 (msg %s): %s", msg.id, e)
        reacted_per_post[msg.id] = users
        if progress and i % 10 == 0:
            try:
                await progress.edit(content=f"집계 중... {i}/{len(posts)}")
            except discord.HTTPException:
                pass
        await asyncio.sleep(0)  # 이벤트 루프 양보 (하트비트 끊김 방지)

    done = set()
    for uid in targets:
        others = [m for m in posts if m.author.id != uid]
        if not others:
            done.add(uid)
            continue
        hit = sum(1 for m in others if uid in reacted_per_post[m.id])
        if (hit == len(others)) if 전체반응 else (hit > 0):
            done.add(uid)
    not_done = targets - done

    embed = discord.Embed(
        title=f"{이모지 or '🔎'} 반응 체크 결과",
        description=(
            f"대상: **{target_desc}** ({len(targets)}명)\n"
            f"검사 글 {len(posts)}개 · 기준: {'모든 글에 반응' if 전체반응 else '1개 이상 반응'}\n"
            f"**완료 {len(done)}명 / 미완료 {len(not_done)}명**"
        ),
        color=0x2ECC71 if not not_done else 0xE74C3C,
    )
    add_list_field(embed, f"✅ 누른 사람 ({len(done)})", interaction.guild, done)
    add_list_field(embed, f"❌ 안 누른 사람 ({len(not_done)})", interaction.guild, not_done)

    kv_set(f"last:{interaction.guild_id}",
           {"ids": sorted(not_done), "reason": "아직 이모지를 안 누르셨어요"})

    if progress:
        await progress.edit(content=None, embed=embed)
    else:
        await interaction.followup.send(embed=embed)


# ── 글 작성 체크 ─────────────────────────────────────────────
@bot.tree.command(name="글작성체크", description="대상자 중 이 채널에 글을 안 쓴 사람을 찾습니다.")
@app_commands.describe(개수="훑어볼 최근 메시지 수", 음성채널="대상 음성 채널", 역할="대상 역할")
async def post_check(
    interaction: discord.Interaction,
    개수: app_commands.Range[int, 1, 200] = 50,
    음성채널: discord.VoiceChannel | None = None,
    역할: discord.Role | None = None,
):
    await interaction.response.defer()
    resolved = resolve_targets(interaction, 음성채널, 역할)
    if resolved is None:
        await interaction.followup.send("음성 채널에 들어가거나 `음성채널`/`역할` 옵션을 지정해주세요.")
        return
    targets, target_desc = resolved

    authors = {m.author.id async for m in interaction.channel.history(limit=개수) if not m.author.bot}
    wrote, missing = targets & authors, targets - authors

    embed = discord.Embed(
        title="📝 글 작성 체크",
        description=f"대상: **{target_desc}** ({len(targets)}명)\n**작성 {len(wrote)}명 / 미작성 {len(missing)}명**",
        color=0x2ECC71 if not missing else 0xE67E22,
    )
    add_list_field(embed, f"✅ 작성함 ({len(wrote)})", interaction.guild, wrote)
    add_list_field(embed, f"❌ 미작성 ({len(missing)})", interaction.guild, missing)

    kv_set(f"last:{interaction.guild_id}",
           {"ids": sorted(missing), "reason": "아직 회고를 안 쓰셨어요"})
    await interaction.followup.send(embed=embed)


# ── 독촉 ─────────────────────────────────────────────────────
@bot.tree.command(name="독촉", description="마지막 집계의 미완료자를 멘션합니다. (재시작해도 유지)")
async def remind(interaction: discord.Interaction):
    data = kv_get(f"last:{interaction.guild_id}")
    if not data or not data["ids"]:
        await interaction.response.send_message("독촉할 대상이 없습니다. 🎉")
        return

    await interaction.response.send_message(f"📣 {data['reason']}")
    buf = ""
    for m in (f"<@{u}>" for u in data["ids"]):
        if len(buf) + len(m) + 1 > 1900:
            await interaction.channel.send(buf)
            buf = m
        else:
            buf += (" " if buf else "") + m
    if buf:
        await interaction.channel.send(buf)


# ── 진단 ─────────────────────────────────────────────────────
@bot.tree.command(name="상태", description="봇이 살아있는지, 명령이 정상 등록됐는지 확인합니다.")
async def status(interaction: discord.Interaction):
    cmds = await bot.tree.fetch_commands(guild=discord.Object(id=GUILD_ID)) if GUILD_ID \
        else await bot.tree.fetch_commands()
    await interaction.response.send_message(
        f"🟢 정상\n지연: {bot.latency * 1000:.0f}ms\n등록된 명령: {len(cmds)}개\n"
        f"모드: {'길드' if GUILD_ID else '전역'}",
        ephemeral=True,
    )


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN 환경변수를 설정해주세요.")
    # reconnect=True 가 기본이라 일시적 끊김은 알아서 복구된다.
    # 프로세스 자체가 죽는 경우는 systemd/Docker 재시작 정책으로 처리할 것.
    bot.run(TOKEN, log_handler=None)

@echo off
chcp 65001 > nul
cd /d "%~dp0"
title 디스코드 회고 체크 봇

REM ============================================================
REM   아래 두 줄의 "여기에..." 부분만 지우고 붙여넣으세요.
REM   따옴표 없이, 등호(=) 바로 뒤에 붙여쓰면 됩니다.
REM   예)  set DISCORD_TOKEN=MTIzNDU2Nzg5.AbCdEf.gHiJkLmNoP
REM ============================================================

set DISCORD_TOKEN=여기에_봇_토큰_붙여넣기
set GUILD_ID=여기에_서버_ID_붙여넣기

REM ============================================================

echo.
echo  [1/2] 필요한 프로그램을 확인하는 중입니다...
echo.
python -m pip install --upgrade --quiet discord.py
if errorlevel 1 (
    echo.
    echo  [!] 실패했습니다. Python이 설치되어 있지 않을 수 있습니다.
    echo      python.org 에서 설치할 때 "Add python.exe to PATH" 를
    echo      반드시 체크했는지 확인해주세요.
    echo.
    pause
    exit /b
)

echo  [2/2] 봇을 실행합니다.
echo.
echo  ============================================
echo   이 창을 닫으면 봇이 꺼집니다. 켜둔 채로 두세요.
echo  ============================================
echo.

python retro_check_bot_stable.py

echo.
echo  봇이 종료되었습니다. 위에 나온 오류 메시지를 확인해주세요.
pause

package model;

import java.io.*; // i = input , / o output   / * = all
import java.util.ArrayList;
import java.util.List;

/**
 * [Model - Persistence Layer (영속성 계층)]
 * 데이터베이스 역할을 대신하여 메모리(List)와 디스크 파일(CSV)에 CRUD 작업을 수행합니다.
 * 프로그램이 꺼져도 파일 입출력을 통해 데이터가 안전하게 유지됩니다.
 */
public class BowlerRepository {
    // 다형성을 적용하여 일반 회원과 VIP 회원을 하나의 List로 통합 관리합니다.
	//타입 매개 변수화(데이터 타입을 인스턴스 생성 시점에 외부에서 결정), <> 생략가능 좌항에서 사용했으므로 관용적 표현.
	//제네릭(Generic)을 사용한 이유는 이 리스트에는 오직 Bowler 객체만 담겠다고 안전장치를 걸어둔 것
	//형변환 생략 가능.
    private List<Bowler> bowlers = new ArrayList<>(); 
    private final String FILE_PATH = "bowlers.csv"; // final 을 사용한 이유 : 코드값을 바꿀수 없게 하기위해(저장공간을 한곳으로 유지)
    private int nextId = 1; // 자동 증가할 회원 고유 ID 고유값

    public BowlerRepository() {
        loadFromFile(); // 레포지토리가 생성될 때 기존 파일 데이터를 복구합니다.
    }

    // === [Create] 회원 정보 추가 ===
    public void addBowler(Bowler bowler) {
        bowlers.add(bowler);  // add를 사용한 이유: 컬렉션 프레임워크 저장하는 데이터 수에 따라 크기가 자동 조절됨. 
        if (bowler.getId() >= nextId) {
            nextId = bowler.getId() + 1; // 중복 ID 방지를 위한 인덱스 갱신
        }
        saveToFile(); // 데이터가 변경될 때마다 자동 저장 (데이터 무결성 보장)
    }

    // === [Read] 전체 회원 데이터 조회 ===
    //제네릭으로 오브젝트 오류 발생을 막음
    //형변환을 여러번 할 필요가 없다.
    public List<Bowler> getAllBowlers() {
        return new ArrayList<>(bowlers); // 외부에서 직접 리스트를 조작하지 못하도록 방어적 복사 수행
    }

    // === [Read] ID값으로 특정 회원 단건 조회 ===
    public Bowler findById(int id) {
        for (Bowler b : bowlers) {
            if (b.getId() == id) return b;
        }
        return null; // 찾지 못한 경우 null 반환
    }

    // === [Update] 레인 변경 및 게임 수 갱신 ===
    public boolean updateBowler(int id, int newLane, int newGameCount) {
        Bowler bowler = findById(id);
        if (bowler != null) {
            bowler.setLaneNumber(newLane);
            bowler.setGameCount(newGameCount);
            saveToFile(); // 수정 내역 즉시 파일 갱신
            return true;
        }
        return false; // 대상이 없을 경우 false 반환
    }

    // === [Delete] 회원 정보 삭제 ===
    public boolean deleteBowler(int id) {
        Bowler bowler = findById(id);
        if (bowler != null) {
            bowlers.remove(bowler);
            saveToFile(); // 삭제 내역 즉시 파일 갱신
            return true;
        }
        return false;
    }

    // 고유 ID 발급기
    public int getNextId() {
        return nextId++;
    }

    // === [File I/O - Save] 파일에 데이터 쓰기 ===
    private void saveToFile() {
    	//try - with -resources  (try ()): 괄호 안에서 파일 도구를 생성하면,
        //try 블록이 끝날 때 자바가 자동으로 close()를 호출하여 파일을 안전하게 닫아줍니다.
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) { 
            for (Bowler b : bowlers) {
                bw.write(b.toCsvString());
                bw.newLine(); // 한 줄 씩 데이터 구분 저장
            }
        } catch (IOException e) {
            System.out.println("파일 저장 중 입출력 오류가 발생했습니다: " + e.getMessage());
        }
    }

    // === [File I/O - Load] 파일에서 데이터 읽어오기 ===
    private void loadFromFile() {
        File file = new File(FILE_PATH);
        if (!file.exists()) return; // 초기 실행 시 파일이 없으면 처리 건너뜀

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                // 빈 줄이거나 공백만 있는 줄은 건너뜁니다.
                if (line.trim().isEmpty()) {
                    continue;
                }

                // 쉼표 단위로 텍스트 분구 파싱
                String[] data = line.split(",");
                
                // 💡 해결책: 데이터 개수가 부족하면 정상적인 데이터가 아니므로 건너뜁니다.
                if (data.length < 5) {
                    System.out.println("[경고] 데이터 형식이 올바르지 않아 건너뜁니다: " + line);
                    continue;
                }

                try {
                    int id = Integer.parseInt(data[0].trim());
                    String name = data[1].trim();
                    int lane = Integer.parseInt(data[2].trim());
                    int gameCount = Integer.parseInt(data[3].trim());
                    String grade = data[4].trim();

                    // 파일의 등급 데이터에 맞춰 적절한 객체 타입으로 동적 생성 (다형성 활용)
                    if ("VIP".equals(grade)) {
                        bowlers.add(new VipBowler(id, name, lane, gameCount));
                    } else {
                        bowlers.add(new Bowler(id, name, lane, gameCount));
                    }

                    if (id >= nextId) nextId = id + 1; // 다음 자동 증가 ID 위치 보정
                    
                } catch (NumberFormatException e) {
                    // 💡 해결책: 파일에 문자가 잘못 섞여있어도 프로그램이 터지지 않고 에러 줄만 스킵합니다.
                    System.out.println("[오류] 파일 데이터 숫자가 올바르지 않습니다: " + line);
                }
            }
        } catch (IOException e) {
            System.out.println("파일 로딩 중 입출력 오류가 발생했습니다: " + e.getMessage());
        }
    }
}

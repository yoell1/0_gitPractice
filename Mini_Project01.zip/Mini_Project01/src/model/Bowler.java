package model;

/**
 * [Model - Abstraction & Extends]
 * 모든 회원의 공통 속성을 정의하는 부모 클래스입니다.
 * 객체 지향의 '상속'과 '캡슐화'를 보여주기 위해 필드를 private으로 제한하고 Getter/Setter를 제공합니다.
 */
public class Bowler {
    private int id;              // 회원 고유 번호 (조회, 수정, 삭제의 키값)
    private String name;         // 회원 이름
    private int laneNumber;      // 배정된 볼링 레인 번호
    private int gameCount;       // 누적 게임 수 (비용 계산용)

    // 게임당 기본 비용 상수 설정 (1게임당 5,000원)
    //final 을 쓴 이유는 변경을 못하게 하려고. 상수값 고정.
    public static final int BASE_PRICE_PER_GAME = 5000;

    public Bowler(int id, String name, int laneNumber, int gameCount) {
        this.id = id;
        this.name = name;
        this.laneNumber = laneNumber;
        this.gameCount = gameCount;
    }

    // --- Getter / Setter (캡슐화 보장) ---
    public int getId() { return id; }
    public String getName() { return name; }
    public int getLaneNumber() { return laneNumber; }
    public void setLaneNumber(int laneNumber) { this.laneNumber = laneNumber; }
    public int getGameCount() { return gameCount; }
    public void setGameCount(int gameCount) { this.gameCount = gameCount; }
    

    /**
     * [다형성 - Polymorphism]
     * 회원 등급명을 반환합니다. 자식 클래스에서 오버라이딩하여 동적 바인딩을 구현합니다.
     */
    public String getGrade() {
        return "일반";
    }

    /**
     * [게임당 비용 계산]
     * 일반 회원은 할인 없이 (게임 수 * 기본 비용)을 지불합니다.
     */
    public int calculateTotalFee() {
        return this.gameCount * BASE_PRICE_PER_GAME;
    }

    /**
     * [영속성 - CSV 직렬화]
     * 객체의 데이터를 쉼표(,)로 구분된 텍스트 파일 구조로 변환합니다.
     * 직렬화의 이유 
     * 자바 프로그램 내부의 객체(Object) 데이터는 메모리(RAM)에만 일시적으로 존재하기 때문에,
     * 하드디스크 같은 외부 파일에 저장하거나 네트워크로 전송할 수 있는 일반적인 텍스트 형태로 바꾸어야 하기 때문
     */
    public String toCsvString() {
        return id + "," + name + "," + laneNumber + "," + gameCount + "," + getGrade();
    }

    @Override
    public String toString() {
        return String.format("[%s회원] ID: %d | 이름: %s | 배정레인: %d번 | 이용게임: %d판 | 총 결제금액: %,d원",
                getGrade(), id, name, laneNumber, gameCount, calculateTotalFee());
    }
}

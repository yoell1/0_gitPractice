package model;

/**
 * [Model - Extends & Polymorphism]
 * Bowler 클래스를 상속받아 정기 회원 중 VIP 혜택을 받는 구조를 설계했습니다.
 * 다형성을 활용하여 등급별로 게임당 비용을 다르게 정산합니다.
 */
public class VipBowler extends Bowler {
    
    // VIP 회원은 게임당 20% 할인이 적용됩니다 (게임당 4,000원)
    private static final double DISCOUNT_RATE = 0.8; 

    public VipBowler(int id, String name, int laneNumber, int gameCount) {
        // 부모 클래스의 생성자를 호출하여 초기화 위임
        super(id, name, laneNumber, gameCount);
    }

    /**
     * [메서드 오버라이딩 - 다형성]
     * 부모의 등급 반환 메서드를 재정의하여 VIP 등급을 명시합니다.
     */
    @Override
    public String getGrade() {
        return "VIP";
    }

    /**
     * [메서드 오버라이딩 - 로직 변경]
     * VIP 회원만의 할인된 게임당 비용 계산 공식을 적용합니다.
     */
    @Override
    public int calculateTotalFee() {
        return (int) (getGameCount() * BASE_PRICE_PER_GAME * DISCOUNT_RATE);
    }
}

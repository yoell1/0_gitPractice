package controller;

import java.util.List;
import model.Bowler;
import model.BowlerRepository;
import model.VipBowler;
import view.BowlingView;

/**
 * [Controller - 비즈니스 로직 제어]
 * View가 보낸 사용자의 요청 신호(메서드 호출)를 받아 
 * Model(Repository)의 적절한 CRUD 기능과 매핑하여 데이터를 처리합니다.
 */
public class BowlingController {
    private BowlerRepository repository;
    private BowlingView view;

    public BowlingController(BowlerRepository repository, BowlingView view) {
        this.repository = repository;
        this.view = view;
    }

    // === [Create 처리] ===
    public void createProcess() {
        String name = view.inputString("볼러(회원) 이름 입력");
        int lane = inputValidInt("배정할 볼링 레인 번호 (1~20)", 0, 21);
        int games = view.inputInt("기본 이용 게임 수 설정");
        int type = view.inputInt("회원 등급 선택 (1.일반회원 / 2.VIP회원 - 게임비 할인)");

        int generatedId = repository.getNextId();
        Bowler newBowler;

        if (type == 2) {
            newBowler = new VipBowler(generatedId, name, lane, games);
        } else {
            newBowler = new Bowler(generatedId, name, lane, games);
        }

        repository.addBowler(newBowler);
        view.printAlert(name + " 볼러가 성공적으로 등록 및 배정되었습니다. (부여된 고유 ID: " + generatedId + ")");
    }

    // === [Read 처리] ===
    public void readProcess() {
        List<Bowler> currentList = repository.getAllBowlers();
        view.printAllBowlers(currentList);
    }

    // === [Update 처리] ===
    public void updateProcess() {
        int id = view.inputInt("정보를 변경할 볼러의 고유 ID 입력");
        Bowler target = repository.findById(id);

        if (target == null) {
            view.printAlert("입력하신 ID에 해당하는 사용자를 데이터베이스에서 찾을 수 없습니다.");
            return;
        }

        int updateLane = inputValidInt("이동 및 새로 지정할 레인 번호 (1~20)", 0, 21);
        int updateGames = view.inputInt("새로 갱신할 총 누적 게임 수");

        if (repository.updateBowler(id, updateLane, updateGames)) {
            view.printAlert("ID [" + id + "]번 회원의 레인 및 게임수 변경 내역이 안전하게 영속화되었습니다.");
        }
    }

    // === [Delete 처리] ===
    public void deleteProcess() {
        int id = view.inputInt("볼링장을 퇴실(삭제) 처리할 회원의 고유 ID 입력");
        if (repository.deleteBowler(id)) {
            view.printAlert("ID [" + id + "]번 회원의 데이터가 파일 및 시스템에서 정상 삭제되었습니다.");
        } else {
            view.printAlert("일치하는 회원 고유 번호가 존재하지 않아 삭제가 취소되었습니다.");
        }
    }

    // === [lane 숫자 오류 처리 도우미] ===
    private int inputValidInt(String message, int min, int max) {
        while (true) {
            int input = view.inputInt(message);
            if (input > min && input < max) {
                return input; 
            }
            view.printAlert("[오류] " + (min + 1) + "부터 " + (max - 1) + " 사이의 숫자만 입력 가능합니다.");
        }
    }
}

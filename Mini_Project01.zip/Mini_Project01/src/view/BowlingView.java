package view;

import controller.BowlingController;
import model.Bowler;
import model.BowlerRepository;

import java.util.List;
import java.util.Scanner;

/**
 * [View - 메인 루프 구동 및 UI]
 * 프로그램의 시작 루프를 돌리며, 사용자의 메뉴 선택에 따라 
 * 컨트롤러(Controller)의 비즈니스 로직 메서드를 직접 호출하여 실행합니다.
 */
public class BowlingView {
    private Scanner scanner;
    private BowlingController controller; // 컨트롤러를 필드로 가집니다.

    public BowlingView() {
        this.scanner = new Scanner(System.in);
        
        // 의존성 조립: 레포지토리를 만들고, 이를 나와 함께 컨트롤러에 주입합니다.
        BowlerRepository repository = new BowlerRepository();
        this.controller = new BowlingController(repository, this);
    }

    /**
     * 프로그램 구동 엔진 (뷰가 주도권을 쥠)
     */
    public void start() {
        while (true) {
            int menuChoice = showMainMenu();
            
            // 향상된 switch문으로 사용자의 선택에 맞는 컨트롤러의 기능을 실행
            //case  -> 내용 ; break; 생략(자동으로 break; 됨)
            switch (menuChoice) {
                case 1 -> controller.createProcess();  // [Create]
                case 2 -> controller.readProcess();    // [Read]
                case 3 -> controller.updateProcess();  // [Update]
                case 4 -> controller.deleteProcess();  // [Delete]
                case 5 -> {
                    printAlert("프로그램을 안전하게 종료합니다. 모든 내역이 영구 저장되었습니다.");
                    return; // 루프 종료 및 프로그램 종료
                }
                default -> printAlert("메뉴판에 정의된 올바른 번호(1~5)를 선택해주세요.");
            }
        }
    }

    // ================================================================
    // 순수 UI 렌더링 및 입출력 도우미 메서드들
    // ================================================================

    public int showMainMenu() {
        System.out.println("\n================  볼링장 관리 시스템 ================");
        System.out.println(" 1. 볼러(회원) 등록        [Create]");
        System.out.println(" 2. 전체 현황 및 비용 조회   [Read]");
        System.out.println(" 3. 이용 레인 및 게임수 수정  [Update]");
        System.out.println(" 4. 회원 등록 취소         [Delete]");
        System.out.println(" 5. 시스템 종료");
        System.out.println("================================================");
        System.out.print("선택 번호 > ");
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public void printAllBowlers(List<Bowler> bowlers) {
        System.out.println("-----------  현재 볼링장 이용객 전체 목록 -----------");
        if (bowlers.isEmpty()) {
            System.out.println("현재 이용 중인 볼러가 존재하지 않습니다.");
            return;
        }
        for (Bowler b : bowlers) {
            System.out.println(b);
        }
        System.out.println("-----------------------------------------------------");
    }

    public String inputString(String message) {
        System.out.print(message + ": ");
        return scanner.nextLine();
    }

    public int inputInt(String message) {
        while (true) {
            try {
                System.out.print(message + ": ");
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("잘못된 입력입니다. 숫자만 입력할 수 있습니다.");
            }
        }
    }

    public void printAlert(String msg) {
        System.out.println("[안내] " + msg);
    }
}

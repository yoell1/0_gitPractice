import view.BowlingView;

public class Main {
    public static void main(String[] args) {
    	// 1. 입출력 및 제어를 담당할 뷰 인스턴스만 생성
        BowlingView view = new BowlingView();
        
        // 2. 뷰를 통해 시스템 구동 시작
        view.start();
    }
}
